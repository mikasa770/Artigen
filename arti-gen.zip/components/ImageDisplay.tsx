import React from 'react';
import { ImageIcon } from './icons/ImageIcon';
import { DownloadIcon } from './icons/DownloadIcon';
import { LoadingSpinner } from './icons/LoadingSpinner';

interface ImageDisplayProps {
  imageUrl: string | null;
  isLoading: boolean;
}

export const ImageDisplay: React.FC<ImageDisplayProps> = ({ imageUrl, isLoading }) => {
  const Placeholder = () => (
    <div className="flex flex-col items-center justify-center h-full gap-6 text-slate-500">
      <div className="bg-slate-700/50 rounded-full p-6">
        <ImageIcon className="w-16 h-16 text-slate-500" />
      </div>
      <p className="text-center text-slate-400">Your generated art will appear here.</p>
    </div>
  );

  const Loader = () => (
    <div className="flex flex-col items-center justify-center h-full gap-4 text-slate-400">
      <LoadingSpinner className="w-16 h-16" />
      <p className="text-lg animate-pulse">Creating your masterpiece...</p>
    </div>
  );

  return (
    <div className="w-full aspect-square bg-[#171c26] rounded-xl flex items-center justify-center p-4 relative group">
      {isLoading ? (
        <Loader />
      ) : imageUrl ? (
        <>
          <img 
            src={imageUrl} 
            alt="Generated art" 
            className="w-full h-full object-cover rounded-lg shadow-2xl" 
          />
          <a
            href={imageUrl}
            download="art-gen-creation.jpg"
            className="absolute bottom-4 right-4 bg-black/50 text-white p-3 rounded-full backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300 hover:bg-blue-600 transform hover:scale-110"
            aria-label="Download Image"
          >
            <DownloadIcon className="w-6 h-6" />
          </a>
        </>
      ) : (
        <Placeholder />
      )}
    </div>
  );
};