
import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="w-full mt-12 py-6 border-t border-slate-800">
      <div className="container mx-auto px-4 text-center text-slate-500">
        <p>Powered by Google Gemini. Create something amazing.</p>
      </div>
    </footer>
  );
};
