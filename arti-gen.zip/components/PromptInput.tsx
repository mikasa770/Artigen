import React from 'react';

interface PromptInputProps {
  value: string;
  onChange: (value: string) => void;
}

export const PromptInput: React.FC<PromptInputProps> = ({ value, onChange }) => {
  return (
    <textarea
      id="prompt"
      rows={4}
      className="w-full bg-slate-800/60 border-0 rounded-lg p-3 focus:ring-1 focus:ring-blue-500 focus:outline-none transition-colors duration-200 placeholder-slate-400 text-slate-200 resize-none"
      placeholder="A synthwave landscape with a retro car driving into the sunset."
      value={value}
      onChange={(e) => onChange(e.target.value)}
    />
  );
};