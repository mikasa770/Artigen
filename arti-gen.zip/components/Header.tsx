import React from 'react';
import { SparklesIcon } from './icons/SparklesIcon';

export const Header: React.FC = () => {
  return (
    <header className="bg-[#10141a]/80 backdrop-blur-sm border-b border-slate-700/50 sticky top-0 z-20">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center gap-3">
            <SparklesIcon className="h-6 w-6 text-blue-400" />
            <h1 className="text-lg font-bold text-slate-100 tracking-tight">
                Arti Gen
            </h1>
        </div>
      </div>
    </header>
  );
};