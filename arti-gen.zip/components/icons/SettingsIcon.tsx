import React from 'react';

export const SettingsIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    fill="none" 
    viewBox="0 0 24 24" 
    strokeWidth={1.5} 
    stroke="currentColor" 
    {...props}>
    <path 
        strokeLinecap="round" 
        strokeLinejoin="round" 
        d="M9.594 3.94c.09-.542.56-1.007 1.11-.962a8.25 8.25 0 015.584 5.584c.045.55-.422 1.02-.962 1.11l-3.328.708a.75.75 0 00-.577.577l-.708 3.328c-.09.542-.56 1.007-1.11.962a8.25 8.25 0 01-5.584-5.584c-.045-.55.422-1.02.962-1.11L9.594 3.94z" 
    />
    <path 
        strokeLinecap="round" 
        strokeLinejoin="round" 
        d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" 
    />
  </svg>
);