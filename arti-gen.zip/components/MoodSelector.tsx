import React from 'react';
import { Mood, MoodOption } from '../types';

interface MoodSelectorProps {
  moods: MoodOption[];
  selectedMood: Mood;
  onSelectMood: (mood: Mood) => void;
}

export const MoodSelector: React.FC<MoodSelectorProps> = ({ moods, selectedMood, onSelectMood }) => {
  return (
    <div className="flex flex-wrap gap-3">
      {moods.map((moodOption) => (
        <button
          key={moodOption.value}
          onClick={() => onSelectMood(moodOption.value)}
          className={`px-4 py-2 text-sm font-semibold rounded-lg transition-colors duration-200 ease-in-out
            ${
              selectedMood === moodOption.value
                ? 'bg-blue-600 text-white shadow-lg'
                : 'bg-slate-700 hover:bg-slate-600 text-slate-300'
            }`}
        >
          {moodOption.label}
        </button>
      ))}
    </div>
  );
};