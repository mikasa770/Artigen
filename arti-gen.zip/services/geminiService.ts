
import { GoogleGenAI } from "@google/genai";
import { Mood } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Generates an image using the Imagen model based on a prompt and a mood.
 * @param prompt The user's text prompt.
 * @param mood The selected mood for the image.
 * @returns A base64 encoded JPEG image string.
 */
export const generateImage = async (prompt: string, mood: Mood): Promise<string> => {
  const enhancedPrompt = `Art. The user's prompt is: "${prompt}". The overall mood should be extremely ${mood}. Visually stunning, high-resolution, award-winning art style.`;

  try {
    const response = await ai.models.generateImages({
        model: 'imagen-3.0-generate-002',
        prompt: enhancedPrompt,
        config: {
          numberOfImages: 1,
          outputMimeType: 'image/jpeg',
          aspectRatio: '1:1',
        },
    });

    if (response.generatedImages && response.generatedImages.length > 0) {
        const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
        return `data:image/jpeg;base64,${base64ImageBytes}`;
    } else {
        throw new Error("The API did not return any images.");
    }
  } catch (e) {
    console.error("Error calling Gemini API:", e);
    const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
    throw new Error(`Image generation failed. ${errorMessage}`);
  }
};